import asyncio, os, sqlite3, json, time, re, pathlib
from dataclasses import dataclass
from typing import Dict, Tuple
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from dotenv import load_dotenv
import httpx
from datetime import datetime

# --------- Load ENV ---------
load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_GROUP_ID = int(os.getenv("ALLOWED_GROUP_ID", "0"))
ADMINS = {int(x) for x in os.getenv("ADMINS","").split(",") if x.strip()}
TRIAL_DAYS = int(os.getenv("TRIAL_DAYS","3"))
TRIAL_GB = int(os.getenv("TRIAL_GB","0"))

# --------- Profiles ---------
@dataclass
class Profile:
    name: str
    base_url: str
    username: str
    password: str
    inbound_id: int
    cost_per_code: int

def parse_profiles() -> Dict[str, Profile]:
    raw = os.getenv("PROFILES","")
    out = {}
    for item in [x.strip() for x in raw.split(",") if x.strip()]:
        name, rest = item.split("=",1)
        base_url, u, p, inbound, cost = rest.split("|")
        out[name] = Profile(name, base_url, u, p, int(inbound), int(cost))
    return out

PROFILES = parse_profiles()

# --------- DB ---------
DB = "bot.db"
conn = sqlite3.connect(DB)
cur = conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS users(
    user_id INTEGER PRIMARY KEY,
    credits INTEGER DEFAULT 0
)""")
cur.execute("""CREATE TABLE IF NOT EXISTS logs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER, user_id INTEGER, action TEXT, details TEXT
)""")
conn.commit()

def get_credits(uid:int)->int:
    cur.execute("SELECT credits FROM users WHERE user_id=?",(uid,))
    r = cur.fetchone()
    if not r:
        cur.execute("INSERT OR IGNORE INTO users(user_id,credits) VALUES(?,0)",(uid,))
        conn.commit()
        return 0
    return r[0]

def add_credits(uid:int, amount:int):
    cur.execute("INSERT INTO users(user_id,credits) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET credits=credits+?",
                (uid, amount, amount))
    conn.commit()

def log(uid:int, action:str, details:dict):
    cur.execute("INSERT INTO logs(ts,user_id,action,details) VALUES(?,?,?,?)",
                (int(time.time()), uid, action, json.dumps(details, ensure_ascii=False)))
    conn.commit()

# --------- Helpers for files ---------
BASE_CODES_DIR = pathlib.Path("codes")

def safe_name(s: str) -> str:
    s = s.strip()
    return re.sub(r"[^a-zA-Z0-9ก-๙\-\(\)_\. ]+", "_", s)

def detect_category(profile_name: str) -> str:
    n = profile_name.lower()
    if "ais" in n:   return "ais"
    if "true" in n:  return "true"
    if "dtac" in n:  return "dtac"
    if "my" in n or "cat" in n: return "my"
    return safe_name(profile_name)

def write_code_files(category: str, profile_fullname: str, file_stem: str,
                     human_text: str, raw_json: str):
    folder = BASE_CODES_DIR / category / safe_name(profile_fullname) / datetime.utcnow().strftime("%Y-%m")
    folder.mkdir(parents=True, exist_ok=True)
    stem = safe_name(file_stem)
    txt = folder / f"{stem}.txt"
    jsn = folder / f"{stem}.json"
    if txt.exists() or jsn.exists():
        stamp = datetime.utcnow().strftime("-%Y%m%d-%H%M%S")
        txt = folder / f"{stem}{stamp}.txt"
        jsn = folder / f"{stem}{stamp}.json"
    txt.write_text(human_text, encoding="utf-8")
    jsn.write_text(raw_json, encoding="utf-8")
    return txt, jsn

# --------- 3x-ui API ---------
async def xui_login(client:httpx.AsyncClient, base_url, username, password):
    r = await client.post(f"{base_url}/login",
                          data={"username": username, "password": password},
                          timeout=20, verify=False)
    r.raise_for_status()
    return True

async def xui_add_client(profile:Profile, remark:str, days:int, gb:int) -> Tuple[str,str]:
    async with httpx.AsyncClient(follow_redirects=True) as client:
        await xui_login(client, profile.base_url, profile.username, profile.password)
        expire = int((time.time() + days*86400) * 1000)
        total = 0 if gb==0 else gb * (1024**3)
        payload = {
            "id": profile.inbound_id,
            "settings": None,
            "client": {
                "id": None,
                "email": remark,
                "enable": True,
                "limitIp": 0,
                "totalGB": total,
                "expiryTime": expire,
                "subId": "",
                "reset": 0
            }
        }
        r = await client.post(f"{profile.base_url}/panel/api/inbounds/addClient",
                              json=payload, timeout=30, verify=False)
        r.raise_for_status()
        data = r.json()
        if not data.get("success"):
            raise RuntimeError(f"addClient failed: {data}")

        r2 = await client.get(f"{profile.base_url}/panel/api/inbounds/list", timeout=30, verify=False)
        r2.raise_for_status()
        j2 = r2.json()

        sub_link = None
        for ib in j2.get("obj", []):
            if ib.get("id")==profile.inbound_id:
                if ib.get("subscriptionId"):
                    sub_link = f"{profile.base_url}/sub/{ib['subscriptionId']}"
                break

        summary = (
            f"🧾 Code: {remark}\n"
            f"⏳ Expire: {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(expire/1000))} UTC\n"
            f"🔗 Subscription: {sub_link or '-'}\n"
        )
        raw_all = json.dumps({"addClient":data, "list":j2}, ensure_ascii=False)
        return summary, raw_all

# --------- Bot ---------
bot = Bot(BOT_TOKEN, parse_mode="HTML")
dp = Dispatcher(storage=MemoryStorage())

def in_allowed_group(msg:Message)->bool:
    return msg.chat.type in ("supergroup","group") and msg.chat.id==ALLOWED_GROUP_ID

@dp.message(CommandStart())
async def start(m:Message):
    add_credits(m.from_user.id, 0)
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="/mycredits"), KeyboardButton(text="/mycodes")],
            [KeyboardButton(text="/trialcode")]
        ],
        resize_keyboard=True
    )
    await m.answer(
        "ยินดีต้อนรับ! ใช้คำสั่งต่อไปนี้ได้:\\n"
        "🚀 /addclient - สร้างโค้ดใหม่ (ใช้ในกรุ๊ปที่กำหนดเท่านั้น)\\n"
        "🧾 /mycodes - ดูโค้ดที่คุณเคยสร้าง\\n"
        "💰 /mycredits - ดูเครดิตคงเหลือ\\n"
        "🆓 /trialcode - ทดลอง\\n"
        "💳 /topup <จำนวน> (แอดมิน)\\n"
        "💳 /givecredits (แอดมิน)\\n",
        reply_markup=kb
    )

@dp.message(Command("mycredits"))
async def mycredits(m:Message):
    c = get_credits(m.from_user.id)
    await m.answer(f"ยอดเครดิตของคุณ: <b>{c}</b>")

@dp.message(Command("mycodes"))
async def mycodes(m:Message):
    await m.answer("(เดโม) ประวัติโค้ดเก็บใน logs; สามารถต่อยอดดึงจาก 3x-ui เพิ่มได้")

# ------- FSM สร้างโค้ด -------
class AddClient(StatesGroup):
    waiting_profile = State()
    waiting_filename = State()
    waiting_days = State()
    waiting_gb = State()
    confirm = State()

def profiles_kb():
    rows = [[KeyboardButton(text=name)] for name in PROFILES.keys()]
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True, one_time_keyboard=True)

@dp.message(Command("addclient"))
async def addclient(m:Message, state:FSMContext):
    if not in_allowed_group(m):
        await m.reply("⚠️ คำสั่งนี้ใช้ได้เฉพาะในกลุ่มที่กำหนดเท่านั้น!")
        return
    await m.reply("🔎 กรุณาเลือกโปรไฟล์ที่ต้องการ:", reply_markup=profiles_kb())
    await state.set_state(AddClient.waiting_profile)

@dp.message(AddClient.waiting_profile)
async def _pick_profile(m:Message, state:FSMContext):
    if m.text not in PROFILES:
        await m.reply("โปรดเลือกจากปุ่มด้านล่าง")
        return
    await state.update_data(profile=m.text)
    await m.reply("📝 กรุณาตั้งชื่อไฟล์ (เช่น โปรโมชัน-ลูกค้าA):")
    await state.set_state(AddClient.waiting_filename)

@dp.message(AddClient.waiting_filename)
async def _filename(m:Message, state:FSMContext):
    fname = m.text.strip()
    if not fname:
        await m.reply("กรุณาพิมพ์ชื่อไฟล์อีกครั้ง")
        return
    await state.update_data(filename=fname)
    await m.reply("⏱️ หน่วยเวลา: วัน\\nกรุณาระบุจำนวนวัน (ตัวเลข):")
    await state.set_state(AddClient.waiting_days)

@dp.message(AddClient.waiting_days)
async def _days(m:Message, state:FSMContext):
    try:
        days = int(m.text.strip()); assert days>0
    except:
        await m.reply("กรุณาระบุจำนวนวันเป็นตัวเลขมากกว่า 0")
        return
    await state.update_data(days=days)
    await m.reply("🧮 กรุณาระบุ GB ที่ต้องการจำกัด (หากไม่จำกัดพิมพ์ 0):")
    await state.set_state(AddClient.waiting_gb)

@dp.message(AddClient.waiting_gb)
async def _gb(m:Message, state:FSMContext):
    try:
        gb = int(m.text.strip()); assert gb>=0
    except:
        await m.reply("กรุณาระบุ GB เป็นตัวเลข (0 = ไม่จำกัด)")
        return
    data = await state.get_data()
    prof = PROFILES[data["profile"]]
    cost = prof.cost_per_code
    category = detect_category(prof.name)
    preview_path = f"codes/{category}/{prof.name}/"
    await state.update_data(gb=gb, cost=cost)
    await m.reply(
        "✅ ยืนยันสร้างโค้ด:\\n"
        f"- โปรไฟล์: <b>{prof.name}</b>\\n"
        f"- ไฟล์: <b>{data['filename']}.txt</b>\\n"
        f"- โฟลเดอร์: <code>{preview_path}</code>\\n"
        f"- วัน: <b>{data['days']}</b>\\n"
        f"- จำกัด: <b>{gb} GB</b>\\n"
        f"- หักเครดิต: <b>{cost}</b>\\n"
        "พิมพ์: <b>ยืนยัน</b> เพื่อดำเนินการ"
    )
    await state.set_state(AddClient.confirm)

@dp.message(AddClient.confirm)
async def _confirm(m:Message, state:FSMContext):
    if m.text.strip() != "ยืนยัน":
        await m.reply("ยกเลิกแล้ว")
        await state.clear()
        return
    data = await state.get_data()
    uid = m.from_user.id
    credits = get_credits(uid)
    if credits < data["cost"]:
        await m.reply("❌ เครดิตไม่พอ กรุณา /mycredits หรือให้แอดมินเติมด้วย /topup หรือ /givecredits")
        await state.clear()
        return

    prof = PROFILES[data["profile"]]
    remark = f"{m.from_user.id}-{int(time.time())}"
    try:
        display, raw = await xui_add_client(prof, remark, data["days"], data["gb"])
    except Exception as e:
        await m.reply(f"สร้างโค้ดล้มเหลว: {e}")
        await state.clear()
        return

    add_credits(uid, -data["cost"])
    log(uid, "addclient", {"profile":prof.name, "days":data["days"], "gb":data["gb"], "remark":remark})

    category = detect_category(prof.name)
    human_msg = (
        f"โปรไฟล์: {prof.name}\\n"
        f"วัน: {data['days']} | จำกัด {data['gb']} GB\\n\\n{display}"
    )
    txt_path, json_path = write_code_files(category, prof.name, data["filename"], human_msg, raw)

    await m.reply("✅ โค้ดของคุณถูกส่งไปยังแชทส่วนตัวแล้ว! โปรดตรวจสอบ DM ของคุณ 📬")
    await bot.send_message(uid,
        f"🎟️ โค้ดใหม่ของคุณ\\n"
        f"หมวดหมู่: {category.upper()}\\n"
        f"{human_msg}\\n"
        f"🗂 บันทึกไฟล์ที่: {txt_path}"
    )
    await state.clear()

# ------- Admin: topup -------
@dp.message(Command("topup"))
async def topup(m:Message):
    if m.from_user.id not in ADMINS:
        return
    parts = m.text.split()
    if len(parts)!=2 or not parts[1].isdigit():
        await m.reply("ใช้: /topup <จำนวน> (ตอบแชทของผู้ใช้เป้าหมาย)")
        return
    amount = int(parts[1])
    if not m.reply_to_message:
        await m.reply("ให้ตอบข้อความของผู้ใช้ที่จะเติมเครดิต")
        return
    uid = m.reply_to_message.from_user.id
    add_credits(uid, amount)
    log(m.from_user.id, "topup", {"target":uid,"amount":amount})
    await m.reply(f"เติมเครดิตให้ {uid} จำนวน {amount} แล้ว")

# ------- Trial -------
@dp.message(Command("trialcode"))
async def trialcode(m:Message):
    uid = m.from_user.id
    cur.execute("SELECT COUNT(1) FROM logs WHERE user_id=? AND action='trial'",(uid,))
    if cur.fetchone()[0]>0:
        await m.answer("คุณรับรหัสทดลองไปแล้ว")
        return
    prof = list(PROFILES.values())[0]
    remark = f"trial-{uid}-{int(time.time())}"
    try:
        display, raw = await xui_add_client(prof, remark, TRIAL_DAYS, TRIAL_GB)
    except Exception as e:
        await m.answer(f"ออกโค้ดทดลองล้มเหลว: {e}")
        return
    log(uid, "trial", {"profile":prof.name, "days":TRIAL_DAYS, "gb":TRIAL_GB, "remark":remark})
    fname = f"TRIAL-{uid}-{int(time.time())}"
    category = detect_category(prof.name)
    human_msg = f"[TRIAL]\\nโปรไฟล์: {prof.name}\\nวัน: {TRIAL_DAYS} | จำกัด {TRIAL_GB} GB\\n\\n{display}"
    txt_path, _ = write_code_files(category, prof.name, fname, human_msg, raw)
    await m.answer("✅ ส่งรหัสทดลองไปที่ DM ของคุณแล้ว")
    await bot.send_message(uid, f"🆓 {human_msg}\\n🗂 เก็บไฟล์ที่: {txt_path}")

# ------- Fallback -------
@dp.message()
async def fallback(m:Message):
    if m.text and m.text.startswith("/addclient") and m.chat.id!=ALLOWED_GROUP_ID:
        await m.reply("⚠️ คำสั่งนี้ใช้ได้เฉพาะในกลุ่มที่กำหนดเท่านั้น!")

async def main():
    if not BOT_TOKEN:
        print("ERROR: BOT_TOKEN is empty in .env"); return
    print("Bot running...")
    await Dispatcher(storage=MemoryStorage()).start_polling(Bot(BOT_TOKEN, parse_mode="HTML"))

if __name__ == "__main__":
    # ใช้ dp ที่ประกาศบนสุด (อย่าเรียก main ใหม่)
    async def _run():
        print("Bot running...")
        await dp.start_polling(bot)
    asyncio.run(_run())
