#!/data/data/com.termux/files/usr/bin/bash
set -e
SESSION="xui-bot"
cd "$(dirname "$0")"
# สร้าง venv ถ้ายังไม่มี
[ -d venv ] || python -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
# สร้างโฟลเดอร์ codes ถ้ายังไม่มี
mkdir -p codes
# ใช้ tmux ให้รันตลอด
tmux has-session -t "$SESSION" 2>/dev/null && tmux kill-session -t "$SESSION" || true
tmux new -d -s "$SESSION" "source venv/bin/activate && python bot.py"
echo "Started bot in tmux session: $SESSION"
echo "ดู log: bash tail.sh"
