# Telegram 3x-ui Bot (Termux Edition)
เวอร์ชัน: v2.2 — category + user-filename + Termux scripts

บอทสำหรับสร้างโค้ด 3x-ui ผ่าน Telegram และบันทึกไฟล์ตามหมวดเครือข่าย:
```
codes/<ais|true|dtac|my>/<ชื่อโปรไฟล์เต็ม>/<YYYY-MM>/<ชื่อไฟล์ที่ผู้ใช้ตั้ง>.txt|.json
```

## คุณสมบัติ
- /addclient (ใช้ในกรุ๊ปที่กำหนด) — เลือกโปรไฟล์ → ตั้งชื่อไฟล์ → ระบุวัน → ระบุ GB → ยืนยัน
- /mycredits — ดูเครดิตคงเหลือ
- /trialcode — แจกโค้ดทดลอง (ปรับวัน/GB ได้ใน .env)
- /topup <จำนวน> (แอดมินตอบข้อความเป้าหมาย)
- ระบบหักเครดิต/บันทึก logs (SQLite)
- บันทึกไฟล์โค้ดลงโฟลเดอร์ตามหมวดเครือข่าย

## การติดตั้งบน Termux (ดึงจาก GitHub หรือ Zip นี้)
### วิธี A: ใช้ Zip นี้
1) ดาวน์โหลดไฟล์ zip แล้วแตกไฟล์:
```
termux-setup-storage
cd ~/storage/downloads
unzip telegram-xui-bot-termux.zip -d $HOME
cd ~/telegram-xui-bot-termux
```
2) ติดตั้งและรัน:
```
bash termux_install_local.sh
```
3) แก้ค่าไฟล์ .env ให้ถูกต้อง แล้วเริ่มบอท:
```
nano .env
bash start.sh
```

### วิธี B: GitHub (แนะนำให้คุณอัป ZIP นี้ขึ้น GitHub ของคุณก่อน)
```
pkg update -y && pkg upgrade -y
pkg install -y git python python-venv openssl
git clone https://github.com/<your-account>/<your-repo>.git telegram-xui-bot-termux
cd telegram-xui-bot-termux
bash termux_install_from_repo.sh
nano .env
bash start.sh
```

> Termux ไม่มี systemd — ใช้ `tmux`/`nohup`/`termux-services`. สคริปต์ `start.sh` ใช้ `tmux` ให้แล้ว

## กำหนดค่า .env
ดูไฟล์ `.env.example` แล้วคัดลอกเป็น `.env`
- BOT_TOKEN=โทเค่นบอทจาก @BotFather
- ALLOWED_GROUP_ID=-100xxxxxxxxxx  (ID กรุ๊ปที่จะอนุญาต)
- ADMINS=123456789,987654321       (user_id ของแอดมินคั่นด้วย ,)
- PROFILES=ชื่อโปรไฟล์=BASEURL|USERNAME|PASSWORD|INBOUND_ID|COST_PER_CODE,ชื่อโปรไฟล์2=...
  * ตัวอย่าง:
    AIS-(AisPlay-NoaisPlay)=https://st.fr.bio-th.shop:7899|admin|pass123|1|2,TRUE-Zoom=https://st.fr.bio-th.shop:7899|admin|pass123|2|6
- TRIAL_DAYS=3
- TRIAL_GB=0

## ทำให้รันตลอด
- `bash start.sh` จะเปิด tmux session ชื่อ `xui-bot` (ปิดแอพ Termux ได้ กระบวนการยังอยู่)
- ดู log: `bash tail.sh`
- หยุด: `bash stop.sh`

## หมายเหตุสำคัญเรื่อง 3x-ui API
- เส้นทาง API อาจต่างตามเวอร์ชัน 3x-ui ของคุณ (เช่น `/panel/api/inbounds/addClient`)
- หากสร้างโค้ดไม่สำเร็จ ให้ใช้ curl ตรวจสอบ endpoint และปรับที่ฟังก์ชัน `xui_add_client()` ใน `bot.py`

## โครงสร้างโปรเจ็กต์
- bot.py                — โค้ดบอทหลัก (aiogram v3)
- requirements.txt      — ไลบรารีที่ใช้
- .env.example          — ตัวอย่างไฟล์คอนฟิก
- start.sh / stop.sh / tail.sh — สคริปต์จัดการรันบน Termux (tmux)
- termux_install_local.sh / termux_install_from_repo.sh — ติดตั้งอัตโนมัติ
- codes/                — โฟลเดอร์ที่จะเก็บไฟล์โค้ดตามหมวด

