#!/data/data/com.termux/files/usr/bin/bash
# tail logs from tmux pane (simple approach: show buffer)
SESSION="xui-bot"
tmux attach -t "$SESSION"
