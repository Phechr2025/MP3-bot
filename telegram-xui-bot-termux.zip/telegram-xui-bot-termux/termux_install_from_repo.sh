#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y && pkg upgrade -y
pkg install -y git python python-venv openssl tmux nano
cp -n .env.example .env || true
bash start.sh
