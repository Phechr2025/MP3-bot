#!/data/data/com.termux/files/usr/bin/bash
SESSION="xui-bot"
tmux has-session -t "$SESSION" 2>/dev/null && tmux kill-session -t "$SESSION" && echo "Stopped." || echo "No session."
